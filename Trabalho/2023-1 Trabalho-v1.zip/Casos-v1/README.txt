A pasta "Gabarito" contem todos os casos de testes fornecidos ateh o momento.
A pasta "Trabalhos" eh onde voce deve colocar o seu codigo, caso queira usar o script de correcao 'correcao.sh'.
Apos executar o script de correcao (comando "./correcao.sh"), sera criada uma pasta "Saidas" contendo uma pasta para cada trabalho dentro da "Trabalhos"
A pasta crida tera o executavel do trabalho, o codigo que foi compilado (renomeado para main.c) e a pasta "Testes" com a execucao nos casos de testes fornecidos.
Se o codigo funcionou corretamente, a pasta "Testes" devera ser igdentica a pasta "Gabarito" fornecida.
Apos a execucao do script tambem sera gerado um arquivo notas.csv com a pontuacao obtidada considerando os casos de testes fornecidos.